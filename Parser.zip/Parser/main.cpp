#include<iostream>
#include<fstream>
#include<string>
#include<string.h>
#include<sstream>
#include<vector>
#include<algorithm>
#include<cstdlib>

using std::vector;
using std::ifstream;
using std::string;
using std::cout;
using std::endl;

struct date
{
    int month;
    int day;
    int year;
    date(){};
    date(int Month, int Day, int Year){Month=month; Day=day; Year=year;}
    void out()
    {
        cout<<month<<"/"<<day<<"/"<<year<<endl;
    }
};

struct restarauntInspect
{
    bool operator<(restarauntInspect& r)
    {
        return zipCode < r.zipCode; //uses 'sort' for zipcodes
    }

    int id;
    string dbaName;
    string akaName;
    int license;
    string facilType;
    string risk;
    string address;
    string city;
    string state;
    int zipCode;
    string inspDate;
    string inspType;
    string results;
    string violations;
    string latitude;
    string longitude;
    string location;

    restarauntInspect() {};

    void showData()
    {
        cout<<"           ID:    "<<id<<endl;
        cout<<"     DBA Name:    "<<dbaName<<endl;
        cout<<"     AKA Name:    "<<akaName<<endl;
        cout<<"      License:    "<<license<<endl;
        cout<<"Facility Type:    "<<facilType<<endl;
        cout<<"         Risk:    "<<risk<<endl;
        cout<<"      Address:    "<<address<<endl;
        cout<<"         City:    "<<city<<endl;
        cout<<"        State:    "<<state<<endl;
        cout<<"     ZIP Code:    "<<zipCode<<endl;
        cout<<" Inspect Date:    "<<inspDate<<endl;
        //inspDate.out();

        cout<<" Inspect Type:    "<<inspType<<endl;
        cout<<"      Results:    "<<results<<"\n"<<endl;
        cout<<"      Violations: "<<violations<<"\n"<<endl;
        cout<<"     Latitude:    "<<latitude<<endl;
        cout<<"    Longitude:    "<<longitude<<endl;
        cout<<"     Location:    "<<location<<endl;
        cout<<"\n"<<endl;
    }

    
};

    

int main()
{
    int failCount = 0;
    vector<restarauntInspect> Inspections;
    vector<restarauntInspect> testVect;
    
    ifstream file;
    file.open("Food.csv");

    if(!file.is_open()) {cout<<"File not opened"<<endl;}
    
    //----------------------------------//
    /*while (!file.eof())
    {

        string temp;
        restarauntInspect newR;

        getline(file, newR.id, ','); //id
        //read(temp);
        //temp = newR.id;
        
        getline(file, newR.dbaName, ','); //dbdname
        getline(file, newR.akaName, ','); //akaname
        getline(file, newR.license, ','); //license
        getline(file, newR.facilType, ','); //faciltype
        getline(file, newR.risk, ','); //risk
        getline(file, newR.address, ','); //address
        getline(file, newR.city, ',');//city
        getline(file, newR.state, ','); //state
        getline(file, newR.zipCode, ','); //zip
        getline(file, newR.inspDate, ',');//inspdate
        getline(file, newR.inspType, ',');//insptype
        getline(file, newR.results, ',');//results
        getline(file, newR.violations, ',');//violations
        getline(file, newR.latitude, ',');//latitude
        getline(file, newR.longitude, ',');//longitude
        getline(file, newR.location, ',');//location

       
        Inspections.push_back(newR);        
    }*/
//----------------------------------------//
    string temp;
    while (getline(file, temp)) //reads in file to 'temp'
    {
        restarauntInspect newT;
        int month;
        int day;
        int year;

        string id;
        string dbaName;
        string akaName;
        string license;
        string facilType;
        string risk;
        string address;
        string city;
        string state;
        string zipCode;
        string inspDate;
        string inspType;
        string results;
        string violations;
        string latitude;
        string longitude;
        string location;

        std::stringstream readin(temp); //reads in 'temp'

        string n;
        string x;
        getline(readin, n, ',');          //uses temp to assign
        newT.id = atoi(n.c_str());//converts string to int using atoi and c_str

        getline(readin, newT.dbaName, ',');
        getline(readin, newT.akaName, ',');

        getline(readin, n, ',');
        newT.license = atoi(n.c_str());

        getline(readin, newT.facilType, ',');
        getline(readin, newT.risk, ',');
        getline(readin, newT.address, ',');
        getline(readin, newT.city, ',');
        getline(readin, newT.state, ',');

        getline(readin, n, ',');
        newT.zipCode = atoi(n.c_str());

        getline(readin, newT.inspDate, ','); //dates
        

       /* char c;
        char z;
        char y;
        char f;
        string date;
        n.at(0) = c, n.at(1) = z;
        date = c+z;
        month = atoi(date.c_str());
        
        n.at(3) = c;
        n.at(4) = z;
        date = c+z;
        day = atoi(date.c_str());

        n.at(5)=c;
        n.at(6)=z;
        n.at(7)=y;
        n.at(8)=f;
        date=c+z+y+f;
        year = atoi(date.c_str());

        newT.inspDate.month = month;
        newT.inspDate.day = day;
        newT.inspDate.year = year;*/



        getline(readin, newT.inspType, ',');

        getline(readin, newT.results, ',');

        getline(readin, newT.violations, ',');
        getline(readin, newT.latitude, ',');
        getline(readin, newT.longitude, ',');
        getline(readin, newT.location, ',');

        Inspections.push_back(newT);
        
        temp.clear();
    }
    

    file.close();

    restarauntInspect R;
    std::sort(Inspections.begin(), Inspections.end());
    
    
    for (int i = 0; i<Inspections.size(); i++)
    {
        Inspections[i].showData();
        if (Inspections[i].results == "Fail")
        {
            failCount++;
        }
        
        cout<<""<<endl;
        cout<<"Total Inspections: "<<Inspections.size()<<"\nFailed: "<<failCount<<endl;
    }   

    return 0;
}