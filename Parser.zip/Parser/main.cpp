#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#include<cstdlib>

using std::vector;
using std::ifstream;
using std::string;
using std::cout;
using std::endl;


struct restarauntInspect
{
    string id;
    string dbaName;
    string akaName;
    string license;
    string facilType;
    string risk;
    string address;
    string city;
    string state;
    string zipCode;
    string inspDate;
    string inspType;
    string results;
    string violations;
    string latitude;
    string longitude;
    string location;

    restarauntInspect() {};

    restarauntInspect(string ID, string DbaName, string AkaName, string License, string FacilType, string Risk, string Address,
                      string City, string State, string ZipCode, string InspDate, string InspType, string Results, string Violations, string Latitude, string Longitude, string Location)
    {
        ID = id;
        DbaName = dbaName;
        AkaName = akaName;
        License = license;
        FacilType = facilType;
        Risk = risk;
        Address = address;
        City = city;
        State = state;
        ZipCode = zipCode;
        InspDate = inspDate;
        InspType = inspType;
        Results = results;
        Violations = violations;
        Latitude = latitude;
        Longitude = longitude;
        Location = location;
    }

    void showData()
    {
        cout<<"           ID:"<<id<<endl;
        cout<<"     DBA Name: "<<dbaName<<endl;
        cout<<"     AKA Name: "<<akaName<<endl;
        cout<<"      License: "<<license<<endl;
        cout<<"Facility Type: "<<facilType<<endl;
        cout<<"         Risk: "<<dbaName<<endl;
        cout<<"      Address: "<<address<<endl;
        cout<<"         City: "<<city<<endl;
        cout<<"        State: "<<state<<endl;
        cout<<"     ZIP Code: "<<zipCode<<endl;
        cout<<" Inspect Date: "<<inspDate<<endl;
        cout<<" Inspect Type: "<<inspType<<endl;
        cout<<"      Results: "<<results<<endl;
        cout<<"     Latitude: "<<latitude<<endl;
        cout<<"    Longitude: "<<longitude<<endl;
        cout<<"     Location: "<<location<<endl;
        cout<<""<<endl;
    }

    
};

int main()
{
    vector<restarauntInspect> Inspections;
    
    ifstream file;
    file.open("Food.csv");

    if(!file.is_open()) {cout<<"File not opened"<<endl;}

        /*string id;
        string dbaName;
        string akaName;
        string license;
        string facilType;
        string risk;
        string address;
        string city;
        string state;
        string zipCode;
        string inspDate;
        string inspType;
        string results;
        string violations;*/
    
    while (!file.eof())
    {


        restarauntInspect newR;
        getline(file, newR.id, ',');
        getline(file, newR.dbaName, ',');
        getline(file, newR.akaName, ',');
        getline(file, newR.license, ',');
        getline(file, newR.facilType, ',');
        getline(file, newR.risk, ',');
        getline(file, newR.address, ',');
        getline(file, newR.city, ',');
        getline(file, newR.state, ',');
        getline(file, newR.zipCode, ',');
        getline(file, newR.inspDate, ',');
        getline(file, newR.inspType, ',');
        getline(file, newR.results, ',');
        getline(file, newR.violations, ',');
        getline(file, newR.latitude, ',');
        getline(file, newR.longitude, ',');
        getline(file, newR.location, ',');

        /*restarauntInspect newRestaraunt(id, dbaName, akaName, license, facilType, risk,
                          address, city, state, zipCode, inspDate, inspType, results, violations); */ 

        Inspections.push_back(newR);        
    }
    
    for (int i = 0; i<Inspections.size(); i++)
    {
        Inspections[i].showData();
    }
    

    return 0;
    //cout<<id<<dbaName<<akaName<<license<<endl;
}